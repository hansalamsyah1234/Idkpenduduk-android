package com.example.uts_mobile

data class  PendudukModel(val id:String, val name:String, val ttl: String, val hp: String, val address: String)